# [2048](https://youtu.be/XM2n1gu4530)
- Coding Tutorial: https://youtu.be/XM2n1gu4530
- Demo: https://imkennyyip.github.io/2048/

In this tutorial, you will learn how to build an identical clone of 2048. You will learn how to use the arrow keys to slide numbers around and merge tiles of the same value while totaling up the score.

![2048-preview](https://user-images.githubusercontent.com/78777681/163065518-e4588997-1dde-45b7-a9a6-a7dafcbdf672.png)
